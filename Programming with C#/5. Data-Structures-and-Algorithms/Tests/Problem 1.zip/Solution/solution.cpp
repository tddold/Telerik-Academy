#include <iostream>
using namespace std;
int main()
{
    long t1, t2, t3, n;
    cin >> t1 >> t2 >> t3 >> n;
    if (n == 1) cout << t1 << endl;
    else if (n == 2) cout << t2 << endl;
    else if (n == 3) cout << t3 << endl;
    else
    {
        for(int i = 4; i <= n; i++)
        {
            long tribNew = t1 + t2 + t3;
            t1 = t2;
            t2 = t3;
            t3 = tribNew;
        }
        cout << t3 << endl;
    }
    return 0;
}
