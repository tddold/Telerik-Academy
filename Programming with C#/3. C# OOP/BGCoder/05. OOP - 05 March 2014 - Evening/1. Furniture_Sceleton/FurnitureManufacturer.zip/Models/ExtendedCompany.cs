﻿namespace FurnitureManufacturer.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Engine.Factories;
    using Interfaces;
    using Interfaces.Engine;
    using Engine;
    using Common;

   public static class ExtendedCompany
    {
       public static void AddItemsInCatalog(this Company catalog, Furniture itemType, string itemName)
       {
           
       }
    }
}
