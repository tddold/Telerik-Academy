﻿namespace RefactorIfStaetemans
{
    public class Patato
    {
        private bool isPeeled;
        private bool isRotten;

        public bool IsPeeled { get; set; }

        public bool IsRotten { get; set; }
    }
}
