﻿namespace Chef
{
    public class Bowl
    {
        internal void Add(Vegetables vegetable)
        {
            throw new System.NotImplementedException("TODO");
        }
    }
}