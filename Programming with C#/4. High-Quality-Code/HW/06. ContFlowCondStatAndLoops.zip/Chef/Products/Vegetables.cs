﻿namespace Chef
{
    public abstract class Vegetables
    {
        // TODO
    }
}