﻿namespace Chef
{
    public class Carrot : Vegetables
    {
        // TODO
    }
}