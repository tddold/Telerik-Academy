﻿namespace Chef
{
    public class Patato : Vegetables
    {
        // TODO
    }
}