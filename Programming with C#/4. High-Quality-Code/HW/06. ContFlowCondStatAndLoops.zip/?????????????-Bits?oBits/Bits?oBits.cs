﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace РефацторЕьсам_BitsТoBits
{
    class BitsТoBits
    {
        static void Main(string[] args)
        {
        }
    }
}
