﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Santase.Logic
{
    public enum PlayerPosition
    {
        NoOne = 0,
        FirstPlayer = 1,
        SecondPlayer = 2,
    }
}
