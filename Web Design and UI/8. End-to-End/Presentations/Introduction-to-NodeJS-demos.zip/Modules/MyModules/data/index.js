var car = require('./cars');
var pilots = require('./pilots');

module.exports = {
    car: car,
    pilots: pilots
}