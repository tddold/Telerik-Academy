setInterval(function() {
    console.log('pesho');
}, 2000)

console.log('gosho');